package com.example.almosthomeless.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val landlordId: Int,
    val title: String,
    val price: Double,          // monthly rent in BWP
    val location: String,       // Gaborone area
    val type: String,           // "Single Room", "Double Room", "Flat", "House", "Bachelor"
    val amenities: String,      // comma-separated
    val availabilityDate: String,
    val depositAmount: Double,
    val imageUri: String? = null, // URI of the uploaded image
    val description: String = "",
    val isReserved: Boolean = false,
    val reservedByStudentId: Int = 0
)
