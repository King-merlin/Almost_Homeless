package com.example.almosthomeless.activities

import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import com.example.almosthomeless.R
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.models.Listing
import com.example.almosthomeless.utils.SessionManager
import kotlinx.coroutines.launch

class AddListingActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private var existingListingId: Int = -1
    private var selectedImageUri: Uri? = null

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            selectedImageUri = it
            findViewById<ImageView>(R.id.ivListingImage).load(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_listing)

        db = AppDatabase.getDatabase(this)
        existingListingId = intent.getIntExtra("LISTING_ID", -1)

        val ivListingImage = findViewById<ImageView>(R.id.ivListingImage)
        val btnSelectImage = findViewById<Button>(R.id.btnSelectImage)
        val etTitle       = findViewById<EditText>(R.id.etTitle)
        val etPrice       = findViewById<EditText>(R.id.etPrice)
        val etLocation    = findViewById<EditText>(R.id.etLocation)
        val spinnerType   = findViewById<Spinner>(R.id.spinnerType)
        val etAmenities   = findViewById<EditText>(R.id.etAmenities)
        val etAvailDate   = findViewById<EditText>(R.id.etAvailDate)
        val etDeposit     = findViewById<EditText>(R.id.etDeposit)
        val etDescription = findViewById<EditText>(R.id.etDescription)
        val btnSave       = findViewById<Button>(R.id.btnSave)
        val btnBack       = findViewById<Button>(R.id.btnBack)
        val tvHeader      = findViewById<TextView>(R.id.tvHeader)

        btnBack.setOnClickListener { finish() }

        btnSelectImage.setOnClickListener {
            selectImageLauncher.launch("image/*")
        }

        val types = listOf(
            "Single Room", "Double Room", "Bachelor Flat",
            "2-Bedroom Flat", "Cottage", "House"
        )
        spinnerType.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            types
        )

        if (existingListingId != -1) {
            tvHeader.text = "Edit Listing"
            lifecycleScope.launch {
                val listing = db.listingDao().getListingById(existingListingId) ?: return@launch
                runOnUiThread {
                    etTitle.setText(listing.title)
                    etPrice.setText(listing.price.toString())
                    etLocation.setText(listing.location)
                    val idx = types.indexOf(listing.type)
                    if (idx >= 0) spinnerType.setSelection(idx)
                    etAmenities.setText(listing.amenities)
                    etAvailDate.setText(listing.availabilityDate)
                    etDeposit.setText(listing.depositAmount.toString())
                    etDescription.setText(listing.description)
                    listing.imageUri?.let {
                        selectedImageUri = Uri.parse(it)
                        ivListingImage.load(selectedImageUri)
                    }
                }
            }
        }

        btnSave.setOnClickListener {
            val title     = etTitle.text.toString().trim()
            val priceStr  = etPrice.text.toString().trim()
            val location  = etLocation.text.toString().trim()
            val type      = spinnerType.selectedItem.toString()
            val amenities = etAmenities.text.toString().trim()
            val avail     = etAvailDate.text.toString().trim()
            val depStr    = etDeposit.text.toString().trim()
            val desc      = etDescription.text.toString().trim()

            if (title.isEmpty() || priceStr.isEmpty() || location.isEmpty() || avail.isEmpty()) {
                Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val price   = priceStr.toDoubleOrNull()
            val deposit = depStr.toDoubleOrNull() ?: 0.0

            if (price == null || price <= 0) {
                Toast.makeText(this, "Enter a valid price", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val landlordId = SessionManager.getUserId(this)

            // Random image fallback from the full set h1..h26
            val finalImageUri = if (selectedImageUri != null) {
                selectedImageUri.toString()
            } else {
                val houseImages = listOf("h") + (1..26).map { "h$it" }
                "android.resource://com.example.almosthomeless/drawable/${houseImages.random()}"
            }

            lifecycleScope.launch {
                if (existingListingId == -1) {
                    db.listingDao().insertListing(
                        Listing(
                            landlordId       = landlordId,
                            title            = title,
                            price            = price,
                            location         = location,
                            type             = type,
                            amenities        = amenities,
                            availabilityDate = avail,
                            depositAmount    = deposit,
                            description      = desc,
                            imageUri         = finalImageUri
                        )
                    )
                    runOnUiThread {
                        Toast.makeText(this@AddListingActivity, "Listing added!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val old = db.listingDao().getListingById(existingListingId) ?: return@launch
                    db.listingDao().updateListing(
                        old.copy(
                            title            = title,
                            price            = price,
                            location         = location,
                            type             = type,
                            amenities        = amenities,
                            availabilityDate = avail,
                            depositAmount    = deposit,
                            description      = desc,
                            imageUri         = finalImageUri
                        )
                    )
                    runOnUiThread {
                        Toast.makeText(this@AddListingActivity, "Listing updated!", Toast.LENGTH_SHORT).show()
                    }
                }
                runOnUiThread { finish() }
            }
        }
    }
}
