package com.example.almosthomeless.dao

import androidx.room.*
import com.example.almosthomeless.models.PaymentMethod

@Dao
interface PaymentMethodDao {

    @Insert
    suspend fun insert(method: PaymentMethod): Long

    @Update
    suspend fun update(method: PaymentMethod)

    @Delete
    suspend fun delete(method: PaymentMethod)

    @Query("SELECT * FROM payment_methods WHERE userId = :userId")
    suspend fun getByUser(userId: Int): List<PaymentMethod>

    @Query("SELECT * FROM payment_methods WHERE userId = :userId AND isDefault = 1 LIMIT 1")
    suspend fun getDefault(userId: Int): PaymentMethod?

    @Query("UPDATE payment_methods SET isDefault = 0 WHERE userId = :userId")
    suspend fun clearDefaults(userId: Int)
}
