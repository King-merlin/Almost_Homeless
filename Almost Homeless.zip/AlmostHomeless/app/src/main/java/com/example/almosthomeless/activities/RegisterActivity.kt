package com.example.almosthomeless.activities

import android.content.Intent
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.almosthomeless.R
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.models.User
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private var passwordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        db = AppDatabase.getDatabase(this)

        val etFullName        = findViewById<EditText>(R.id.etFullName)
        val etEmail           = findViewById<EditText>(R.id.etEmail)
        val etPassword        = findViewById<EditText>(R.id.etPassword)
        val btnTogglePassword = findViewById<ImageButton>(R.id.btnTogglePassword)
        val etPhone           = findViewById<EditText>(R.id.etPhone)
        val spinnerRole       = findViewById<Spinner>(R.id.spinnerRole)
        val btnRegister       = findViewById<Button>(R.id.btnRegister)
        val tvLogin           = findViewById<TextView>(R.id.tvGoLogin)

        val roles = listOf("student", "landlord")
        spinnerRole.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, roles
        )

        btnTogglePassword.setOnClickListener {
            passwordVisible = !passwordVisible
            val cursorPos = etPassword.selectionEnd
            if (passwordVisible) {
                etPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
                btnTogglePassword.alpha = 1.0f
            } else {
                etPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                btnTogglePassword.alpha = 0.5f
            }
            etPassword.setSelection(cursorPos)
        }

        btnRegister.setOnClickListener {
            val name  = etFullName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val pass  = etPassword.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val role  = spinnerRole.selectedItem.toString()

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Name, email and password are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Enter a valid email address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (pass.length < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                val exists = db.userDao().emailExists(email)
                if (exists > 0) {
                    runOnUiThread {
                        Toast.makeText(this@RegisterActivity, "Email already registered", Toast.LENGTH_SHORT).show()
                    }
                    return@launch
                }
                db.userDao().register(
                    User(
                        fullname  = name,
                        email     = email,
                        password  = pass,
                        role      = role,
                        phone     = phone,
                        studentId = ""
                    )
                )
                runOnUiThread {
                    Toast.makeText(this@RegisterActivity, "Registration successful! Please login.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
                    finish()
                }
            }
        }

        tvLogin.setOnClickListener { finish() }
    }
}
