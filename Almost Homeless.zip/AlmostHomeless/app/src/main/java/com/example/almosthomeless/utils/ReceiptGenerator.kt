package com.example.almosthomeless.utils

import java.text.SimpleDateFormat
import java.util.*

object ReceiptGenerator {
    fun generate(): String {
        val timestamp = SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(Date())
        val random = (1000..9999).random()
        return "SF-$timestamp-$random"
    }

    fun currentDate(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }
}