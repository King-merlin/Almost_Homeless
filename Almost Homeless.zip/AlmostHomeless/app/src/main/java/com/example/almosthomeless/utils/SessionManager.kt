package com.example.almosthomeless.utils

import android.content.Context
import android.content.SharedPreferences

object SessionManager {

    private const val PREF_NAME = "StayFinderSession"
    private const val KEY_USER_ID = "userId"
    private const val KEY_USER_ROLE = "userRole"
    private const val KEY_USER_NAME = "userName"
    private const val KEY_IS_LOGGED_IN = "isLoggedIn"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun saveSession(context: Context, userId: Int, role: String, name: String) {
        prefs(context).edit()
            .putInt(KEY_USER_ID, userId)
            .putString(KEY_USER_ROLE, role)
            .putString(KEY_USER_NAME, name)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()
    }

    fun getUserId(context: Context): Int = prefs(context).getInt(KEY_USER_ID, -1)

    fun getUserRole(context: Context): String = prefs(context).getString(KEY_USER_ROLE, "") ?: ""

    fun getUserName(context: Context): String = prefs(context).getString(KEY_USER_NAME, "") ?: ""

    fun isLoggedIn(context: Context): Boolean = prefs(context).getBoolean(KEY_IS_LOGGED_IN, false)

    fun clearSession(context: Context) {
        prefs(context).edit().clear().apply()
    }
}