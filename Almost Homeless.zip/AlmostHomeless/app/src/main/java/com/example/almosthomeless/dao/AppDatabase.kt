// Deleted due to redeclaration. The actual database class is in com.example.almosthomeless.database package in the database folder.
