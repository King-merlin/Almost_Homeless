package com.example.almosthomeless.dao

import androidx.room.*
import com.example.almosthomeless.models.Message

@Dao
interface MessageDao {

    @Insert
    suspend fun sendMessage(message: Message): Long

    @Query("""
        SELECT * FROM messages
        WHERE (senderId = :user1 AND receiverId = :user2)
           OR (senderId = :user2 AND receiverId = :user1)
        ORDER BY timestamp ASC
    """)
    suspend fun getChat(user1: Int, user2: Int): List<Message>

    @Query("""
        SELECT DISTINCT CASE WHEN senderId = :userId THEN receiverId ELSE senderId END AS otherId
        FROM messages
        WHERE senderId = :userId OR receiverId = :userId
    """)
    suspend fun getChatPartnerIds(userId: Int): List<Int>
}