package com.example.almosthomeless.dao

import androidx.room.*
import androidx.room.Insert
import com.example.almosthomeless.models.UserFilter

@Dao
interface UserFilterDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveFilter(filter: UserFilter)

    @Query("SELECT * FROM user_filters WHERE userId = :userId LIMIT 1")
    suspend fun getFilter(userId: Int): UserFilter?

    @Delete
    suspend fun deleteFilter(filter: UserFilter)
}