package com.example.almosthomeless.activities

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.load
import com.example.almosthomeless.R
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.models.PaymentMethod
import com.example.almosthomeless.models.Reservation
import com.example.almosthomeless.utils.ReceiptGenerator
import com.example.almosthomeless.utils.SessionManager
import kotlinx.coroutines.launch

class ListingDetailActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listing_detail)

        db = AppDatabase.getDatabase(this)
        val listingId = intent.getIntExtra("LISTING_ID", -1)

        val ivDetailImage   = findViewById<ImageView>(R.id.ivDetailImage)
        val tvTitle         = findViewById<TextView>(R.id.tvTitle)
        val tvPrice         = findViewById<TextView>(R.id.tvPrice)
        val tvLocation      = findViewById<TextView>(R.id.tvLocation)
        val tvType          = findViewById<TextView>(R.id.tvType)
        val tvAmenities     = findViewById<TextView>(R.id.tvAmenities)
        val tvAvailDate     = findViewById<TextView>(R.id.tvAvailDate)
        val tvDeposit       = findViewById<TextView>(R.id.tvDeposit)
        val tvDescription   = findViewById<TextView>(R.id.tvDescription)
        val tvStatus        = findViewById<TextView>(R.id.tvStatus)
        val btnReserve      = findViewById<Button>(R.id.btnReserve)
        val btnChatLandlord = findViewById<Button>(R.id.btnChatLandlord)
        val btnBack         = findViewById<Button>(R.id.btnBack)

        btnBack.setOnClickListener { finish() }

        lifecycleScope.launch {
            val listing = db.listingDao().getListingById(listingId) ?: return@launch
            runOnUiThread {
                if (listing.imageUri != null) {
                    ivDetailImage.load(listing.imageUri) {
                        placeholder(android.R.drawable.ic_menu_gallery)
                        error(android.R.drawable.ic_menu_report_image)
                    }
                }
                tvTitle.text       = listing.title
                tvPrice.text       = "BWP ${listing.price} / month"
                tvLocation.text    = "Location: ${listing.location}"
                tvType.text        = "Type: ${listing.type}"
                tvAmenities.text   = "Amenities: ${listing.amenities}"
                tvAvailDate.text   = "Available: ${listing.availabilityDate}"
                tvDeposit.text     = "Deposit: BWP ${listing.depositAmount}"
                tvDescription.text = listing.description

                if (listing.isReserved) {
                    tvStatus.text = "Reserved"
                    tvStatus.setTextColor(getColor(android.R.color.holo_red_dark))
                    tvStatus.backgroundTintList = android.content.res.ColorStateList.valueOf(0x15B71C1C.toInt())
                    btnReserve.isEnabled = false
                    btnReserve.text = "Not available"
                } else {
                    tvStatus.text = "Available"
                    tvStatus.setTextColor(getColor(android.R.color.holo_green_dark))
                    tvStatus.backgroundTintList = android.content.res.ColorStateList.valueOf(0x152E7D32.toInt())
                    btnReserve.isEnabled = true
                }

                btnReserve.setOnClickListener {
                    initiatePaymentFlow(listing.id, listing.landlordId, listing.depositAmount, listing.title)
                }
                btnChatLandlord.setOnClickListener {
                    startActivity(
                        Intent(this@ListingDetailActivity, ChatActivity::class.java)
                            .putExtra("OTHER_USER_ID", listing.landlordId)
                    )
                }
            }
        }
    }

    private fun initiatePaymentFlow(listingId: Int, landlordId: Int, deposit: Double, title: String) {
        val userId = SessionManager.getUserId(this)
        lifecycleScope.launch {
            val savedMethods = db.paymentMethodDao().getByUser(userId)
            runOnUiThread {
                if (savedMethods.isEmpty()) {
                    showAddPaymentDialog(listingId, landlordId, deposit, title) { method ->
                        showConfirmDialog(listingId, landlordId, deposit, title, method)
                    }
                } else {
                    showPickPaymentDialog(savedMethods, listingId, landlordId, deposit, title)
                }
            }
        }
    }

    private fun showPickPaymentDialog(methods: List<PaymentMethod>, listingId: Int, landlordId: Int, deposit: Double, title: String) {
        val labels = methods.map { "${it.cardBrand} •••• ${it.cardNumberLast4}" }.toMutableList()
        labels.add("Add new payment method")
        AlertDialog.Builder(this)
            .setTitle("Choose payment method")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == methods.size) {
                    showAddPaymentDialog(listingId, landlordId, deposit, title) { method ->
                        showConfirmDialog(listingId, landlordId, deposit, title, method)
                    }
                } else {
                    showConfirmDialog(listingId, landlordId, deposit, title, methods[which])
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddPaymentDialog(listingId: Int, landlordId: Int, deposit: Double, title: String, onSaved: (PaymentMethod) -> Unit) {
        val view         = LayoutInflater.from(this).inflate(R.layout.dialog_add_payment, null)
        val etName       = view.findViewById<EditText>(R.id.etCardName)
        val etNumber     = view.findViewById<EditText>(R.id.etCardNumber)
        val etExpiry     = view.findViewById<EditText>(R.id.etExpiry)
        val spinnerBrand = view.findViewById<Spinner>(R.id.spinnerCardBrand)
        val cbDefault    = view.findViewById<android.widget.CheckBox>(R.id.cbSetDefault)

        spinnerBrand.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Visa", "Mastercard", "Orange Money", "MyZaka")
        )

        AlertDialog.Builder(this)
            .setTitle("Add payment method")
            .setView(view)
            .setPositiveButton("Save & continue") { _, _ ->
                val name   = etName.text.toString().trim()
                val number = etNumber.text.toString().trim().filter { it.isDigit() }
                val expiry = etExpiry.text.toString().trim()
                val brand  = spinnerBrand.selectedItem.toString()

                if (name.isEmpty() || number.length < 4 || expiry.length < 4) {
                    Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val parts = expiry.split("/")
                val month = parts.getOrNull(0)?.toIntOrNull() ?: 0
                val year  = parts.getOrNull(1)?.toIntOrNull()?.let { if (it < 100) 2000 + it else it } ?: 0
                val userId = SessionManager.getUserId(this)

                lifecycleScope.launch {
                    if (cbDefault.isChecked) db.paymentMethodDao().clearDefaults(userId)
                    val id = db.paymentMethodDao().insert(
                        PaymentMethod(
                            userId = userId, cardholderName = name,
                            cardNumberLast4 = number.takeLast(4), cardBrand = brand,
                            expiryMonth = month, expiryYear = year, isDefault = cbDefault.isChecked
                        )
                    )
                    val saved = db.paymentMethodDao().getByUser(userId).find { it.id == id.toInt() }
                    runOnUiThread { if (saved != null) onSaved(saved) }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showConfirmDialog(listingId: Int, landlordId: Int, deposit: Double, title: String, method: PaymentMethod) {
        AlertDialog.Builder(this)
            .setTitle("Confirm reservation")
            .setMessage("Listing: \"$title\"\n\nDeposit: BWP $deposit\nPaying with: ${method.cardBrand} •••• ${method.cardNumberLast4}\n\nProceed with simulated payment?")
            .setPositiveButton("Pay and reserve") { _, _ -> processReservation(listingId, landlordId, deposit) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun processReservation(listingId: Int, landlordId: Int, deposit: Double) {
        val studentId = SessionManager.getUserId(this)
        lifecycleScope.launch {
            val listing = db.listingDao().getListingById(listingId)
            if (listing == null || listing.isReserved) {
                runOnUiThread { Toast.makeText(this@ListingDetailActivity, "This listing is no longer available.", Toast.LENGTH_SHORT).show() }
                return@launch
            }
            val receipt = ReceiptGenerator.generate()
            val date    = ReceiptGenerator.currentDate()
            db.reservationDao().makeReservation(
                Reservation(studentId = studentId, listingId = listingId, landlordId = landlordId,
                    receiptNumber = receipt, paymentAmount = deposit, reservationDate = date, status = "Active")
            )
            db.listingDao().reserveListing(listingId, studentId)
            runOnUiThread {
                AlertDialog.Builder(this@ListingDetailActivity)
                    .setTitle("Reservation confirmed")
                    .setMessage("Receipt: $receipt\nDate: $date\nDeposit paid: BWP $deposit")
                    .setPositiveButton("Done") { _, _ -> finish() }
                    .show()
            }
        }
    }
}
