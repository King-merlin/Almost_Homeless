package com.example.almosthomeless.activities

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.almosthomeless.R
import com.example.almosthomeless.adapters.ListingAdapter
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.models.Listing
import com.example.almosthomeless.utils.SessionManager
import kotlinx.coroutines.launch

class LandlordDashboardActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: ListingAdapter
    private val listings = mutableListOf<Listing>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_landlord_dashboard)

        db = AppDatabase.getDatabase(this)

        val tvWelcome = findViewById<TextView>(R.id.tvWelcome)
        val rv        = findViewById<RecyclerView>(R.id.rvMyListings)
        val btnAdd    = findViewById<Button>(R.id.btnAddListing)
        val btnChat   = findViewById<Button>(R.id.btnChat)
        val btnLogout = findViewById<Button>(R.id.btnLogout)

        tvWelcome.text = "Welcome, ${SessionManager.getUserName(this)}"

        adapter = ListingAdapter(listings) { listing ->
            showListingOptions(listing)
        }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        btnAdd.setOnClickListener {
            startActivity(Intent(this, AddListingActivity::class.java))
        }
        btnChat.setOnClickListener {
            startActivity(Intent(this, ChatListActivity::class.java))
        }
        btnLogout.setOnClickListener {
            SessionManager.clearSession(this)
            startActivity(Intent(this, LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
        }
    }

    override fun onResume() {
        super.onResume()
        loadMyListings()
    }

    private fun loadMyListings() {
        val landlordId = SessionManager.getUserId(this)
        lifecycleScope.launch {
            val result = db.listingDao().getListingsByLandlord(landlordId)
            runOnUiThread {
                listings.clear()
                listings.addAll(result)
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun showListingOptions(listing: Listing) {
        AlertDialog.Builder(this)
            .setTitle(listing.title)
            .setItems(arrayOf("Edit", "Delete")) { _, which ->
                when (which) {
                    0 -> {
                        val intent = Intent(this, AddListingActivity::class.java)
                        intent.putExtra("LISTING_ID", listing.id)
                        startActivity(intent)
                    }
                    1 -> {
                        lifecycleScope.launch {
                            db.listingDao().deleteListing(listing)
                            runOnUiThread {
                                Toast.makeText(
                                    this@LandlordDashboardActivity,
                                    "Listing deleted",
                                    Toast.LENGTH_SHORT
                                ).show()
                                loadMyListings()
                            }
                        }
                    }
                }
            }.show()
    }
}