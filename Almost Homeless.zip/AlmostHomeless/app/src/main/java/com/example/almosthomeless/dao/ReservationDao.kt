package com.example.almosthomeless.dao

import androidx.room.*
import com.example.almosthomeless.models.Reservation

@Dao
interface ReservationDao {

    @Insert
    suspend fun makeReservation(reservation: Reservation): Long

    @Query("SELECT * FROM reservations WHERE studentId = :studentId")
    suspend fun getReservationsByStudent(studentId: Int): List<Reservation>

    @Query("SELECT * FROM reservations WHERE landlordId = :landlordId")
    suspend fun getReservationsByLandlord(landlordId: Int): List<Reservation>

    @Query("SELECT * FROM reservations")
    suspend fun getAllReservations(): List<Reservation>

    @Query("SELECT * FROM reservations WHERE listingId = :listingId LIMIT 1")
    suspend fun getReservationByListing(listingId: Int): Reservation?

    @Update
    suspend fun updateReservation(reservation: Reservation)
}