package com.example.almosthomeless.activities

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.almosthomeless.R
import com.example.almosthomeless.adapters.ListingAdapter
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.models.Listing
import com.example.almosthomeless.utils.NotificationHelper
import com.example.almosthomeless.utils.SessionManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch

class StudentDashboardActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: ListingAdapter
    private val listings = mutableListOf<Listing>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_dashboard)

        NotificationHelper.createNotificationChannel(this)
        db = AppDatabase.getDatabase(this)

        val tvWelcome  = findViewById<TextView>(R.id.tvWelcome)
        val rvListings = findViewById<RecyclerView>(R.id.rvListings)
        val btnFilter  = findViewById<Button>(R.id.btnFilter)
        val bottomNav  = findViewById<BottomNavigationView>(R.id.bottomNav)

        tvWelcome.text = "Welcome, ${SessionManager.getUserName(this)}"

        adapter = ListingAdapter(listings) { listing ->
            startActivity(
                Intent(this, ListingDetailActivity::class.java)
                    .putExtra("LISTING_ID", listing.id)
            )
        }
        rvListings.layoutManager = LinearLayoutManager(this)
        rvListings.adapter = adapter

        btnFilter.setOnClickListener {
            startActivity(Intent(this, FilterActivity::class.java))
        }

        bottomNav.selectedItemId = R.id.nav_home
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatListActivity::class.java))
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    finish()
                    true
                }
                else -> false
            }
        }

        loadListings()
    }

    override fun onResume() {
        super.onResume()
        loadListings()
    }

    private fun loadListings() {
        val userId = SessionManager.getUserId(this)
        lifecycleScope.launch {
            val filter = db.userFilterDao().getFilter(userId)
            val result = if (filter != null) {
                db.listingDao().filterListings(
                    filter.location, filter.type,
                    filter.maxPrice, filter.availabilityDate
                )
            } else {
                db.listingDao().getAvailableListings()
            }

            if (filter != null && result.isNotEmpty()) {
                NotificationHelper.sendListingMatchNotification(
                    this@StudentDashboardActivity, result[0].title, result.size
                )
            }

            runOnUiThread {
                listings.clear()
                listings.addAll(result)
                adapter.notifyDataSetChanged()
            }
        }
    }
}
