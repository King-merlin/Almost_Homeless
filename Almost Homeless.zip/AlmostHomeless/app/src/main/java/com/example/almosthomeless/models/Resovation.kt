package com.example.almosthomeless.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reservations")
data class Reservation(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val studentId: Int,
    val listingId: Int,
    val landlordId: Int,
    val receiptNumber: String,
    val paymentAmount: Double,  // deposit paid
    val reservationDate: String,
    val status: String = "Active" // "Active", "Cancelled"
)
