package com.example.almosthomeless.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.almosthomeless.R
import com.example.almosthomeless.adapters.ReservationAdapter
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.utils.SessionManager
import kotlinx.coroutines.launch

class MyReservationsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_reservations)

        val db     = AppDatabase.getDatabase(this)
        val userId = SessionManager.getUserId(this)

        val rv      = findViewById<RecyclerView>(R.id.rvReservations)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)
        val btnBack = findViewById<Button>(R.id.btnBack)

        btnBack.setOnClickListener { finish() }

        rv.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            val reservations = db.reservationDao().getReservationsByStudent(userId)

            // Enrich with listing titles
            val enriched = reservations.map { res ->
                val listing = db.listingDao().getListingById(res.listingId)
                Pair(res, listing?.title ?: "Unknown Listing")
            }

            runOnUiThread {
                if (enriched.isEmpty()) {
                    tvEmpty.visibility = android.view.View.VISIBLE
                    rv.visibility = android.view.View.GONE
                } else {
                    tvEmpty.visibility = android.view.View.GONE
                    rv.visibility = android.view.View.VISIBLE
                    rv.adapter = ReservationAdapter(enriched)
                }
            }
        }
    }
}