package com.example.almosthomeless.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val fullname: String,
    val email: String,
    val password: String,
    val role: String,          // "student", "landlord", "admin"
    val phone: String = "",
    val studentId: String = "" // only for students
)