package com.example.almosthomeless.activities

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.almosthomeless.R
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.utils.SessionManager
import kotlinx.coroutines.launch

class ChatListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)

        val db     = AppDatabase.getDatabase(this)
        val userId = SessionManager.getUserId(this)
        val role   = SessionManager.getUserRole(this)

        val rv      = findViewById<RecyclerView>(R.id.rvChatList)
        val tvEmpty = findViewById<TextView>(R.id.tvEmpty)
        val btnBack = findViewById<ImageButton>(R.id.btnBack)

        btnBack.setOnClickListener { finish() }
        rv.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            val partnerIds = db.messageDao().getChatPartnerIds(userId)
            val allPartnerIds = if (role == "student") {
                val landlordIds = db.reservationDao()
                    .getReservationsByStudent(userId).map { it.landlordId }
                (partnerIds + landlordIds).distinct()
            } else {
                partnerIds
            }
            val partners = allPartnerIds.mapNotNull { db.userDao().getUserById(it) }

            runOnUiThread {
                if (partners.isEmpty()) {
                    tvEmpty.visibility = android.view.View.VISIBLE
                    rv.visibility      = android.view.View.GONE
                } else {
                    tvEmpty.visibility = android.view.View.GONE
                    rv.visibility      = android.view.View.VISIBLE
                    rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                        override fun getItemCount() = partners.size
                        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                            val layout = LinearLayout(parent.context).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = android.view.Gravity.CENTER_VERTICAL
                                setPadding(16, 14, 16, 14)
                                layoutParams = RecyclerView.LayoutParams(
                                    RecyclerView.LayoutParams.MATCH_PARENT,
                                    RecyclerView.LayoutParams.WRAP_CONTENT
                                )
                                isClickable = true
                                isFocusable = true
                                background = android.util.TypedValue().let { tv ->
                                    context.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                                    ContextCompat.getDrawable(context, tv.resourceId)
                                }
                            }

                            // Avatar circle
                            val avatarFrame = FrameLayout(parent.context).apply {
                                layoutParams = LinearLayout.LayoutParams(44, 44).apply { marginEnd = 14 }
                            }
                            val avatarBg = android.view.View(parent.context).apply {
                                layoutParams = FrameLayout.LayoutParams(44, 44)
                                setBackgroundColor(ContextCompat.getColor(context, R.color.purple_accent))
                            }
                            val avatarText = TextView(parent.context).apply {
                                layoutParams = FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                )
                                gravity = android.view.Gravity.CENTER
                                textSize = 16f
                                setTextColor(ContextCompat.getColor(context, R.color.white))
                                tag = "initial"
                            }
                            avatarFrame.addView(avatarBg)
                            avatarFrame.addView(avatarText)

                            val nameText = TextView(parent.context).apply {
                                textSize = 15f
                                setTextColor(ContextCompat.getColor(context, R.color.primary_text))
                                tag = "name"
                            }

                            layout.addView(avatarFrame)
                            layout.addView(nameText)
                            return object : RecyclerView.ViewHolder(layout) {}
                        }

                        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                            val user   = partners[position]
                            val layout = holder.itemView as LinearLayout
                            val frame  = layout.getChildAt(0) as FrameLayout
                            val initial = frame.findViewWithTag<TextView>("initial")
                            val name    = layout.findViewWithTag<TextView>("name")
                            initial.text = user.fullname.firstOrNull()?.uppercase() ?: "?"
                            name.text    = user.fullname
                            layout.setOnClickListener {
                                startActivity(
                                    Intent(this@ChatListActivity, ChatActivity::class.java)
                                        .putExtra("OTHER_USER_ID", user.id)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
