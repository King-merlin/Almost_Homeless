package com.example.almosthomeless.dao

import androidx.room.*
import com.example.almosthomeless.models.Listing

@Dao
interface ListingDao {

    @Insert
    suspend fun insertListing(listing: Listing): Long

    @Update
    suspend fun updateListing(listing: Listing)

    @Delete
    suspend fun deleteListing(listing: Listing)

    @Query("SELECT * FROM listings")
    suspend fun getAllListings(): List<Listing>

    @Query("SELECT * FROM listings WHERE id = :id LIMIT 1")
    suspend fun getListingById(id: Int): Listing?

    @Query("SELECT * FROM listings WHERE landlordId = :landlordId")
    suspend fun getListingsByLandlord(landlordId: Int): List<Listing>

    @Query("SELECT * FROM listings WHERE isReserved = 0")
    suspend fun getAvailableListings(): List<Listing>

    @Query("UPDATE listings SET isReserved = 1, reservedByStudentId = :studentId WHERE id = :listingId")
    suspend fun reserveListing(listingId: Int, studentId: Int)

    @Query("SELECT * FROM listings WHERE (:location = '' OR location LIKE '%' || :location || '%') AND (:type = '' OR type = :type) AND (:maxPrice = 0.0 OR price <= :maxPrice) AND (:availDate = '' OR availabilityDate <= :availDate)")
    suspend fun filterListings(location: String, type: String, maxPrice: Double, availDate: String): List<Listing>

    @Query("SELECT COUNT(*) FROM listings")
    suspend fun getListingCount(): Int
}