package com.example.almosthomeless.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payment_methods")
data class PaymentMethod(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val cardholderName: String,
    val cardNumberLast4: String,   // only store last 4 digits
    val cardBrand: String,         // "Visa", "Mastercard", "Orange Money", "MyZaka"
    val expiryMonth: Int,
    val expiryYear: Int,
    val isDefault: Boolean = false
)
