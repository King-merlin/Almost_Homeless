package com.example.almosthomeless.activities

import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.almosthomeless.R
import com.example.almosthomeless.utils.SessionManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val ivLogo = findViewById<ImageView>(R.id.ivSplashLogo)
        ivLogo.startAnimation(AnimationUtils.loadAnimation(this, R.anim.splash_logo))

        lifecycleScope.launch {
            delay(1400)
            val intent = if (SessionManager.isLoggedIn(this@SplashActivity)) {
                when (SessionManager.getUserRole(this@SplashActivity)) {
                    "landlord" -> Intent(this@SplashActivity, LandlordDashboardActivity::class.java)
                    else       -> Intent(this@SplashActivity, StudentDashboardActivity::class.java)
                }
            } else {
                Intent(this@SplashActivity, LoginActivity::class.java)
            }
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }
}
