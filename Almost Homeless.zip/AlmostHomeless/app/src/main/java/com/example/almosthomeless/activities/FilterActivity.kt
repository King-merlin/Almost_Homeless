package com.example.almosthomeless.activities

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.almosthomeless.R
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.models.UserFilter
import com.example.almosthomeless.utils.SessionManager
import kotlinx.coroutines.launch
import java.util.Calendar

class FilterActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private var selectedDate: String = ""   // stored as yyyy-MM-dd

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter)

        db = AppDatabase.getDatabase(this)
        val userId = SessionManager.getUserId(this)

        val spinnerLoc  = findViewById<Spinner>(R.id.spinnerFilterLocation)
        val etMaxPrice  = findViewById<EditText>(R.id.etFilterMaxPrice)
        val tvAvailDate = findViewById<TextView>(R.id.tvFilterAvailDate)
        val btnPickDate = findViewById<ImageButton>(R.id.btnPickDate)
        val spinnerType = findViewById<Spinner>(R.id.spinnerFilterType)
        val btnSave     = findViewById<Button>(R.id.btnSaveFilter)
        val btnClear    = findViewById<Button>(R.id.btnClearFilter)
        val btnBack     = findViewById<Button>(R.id.btnBack)

        val locations = listOf("", "Gaborone West", "Tlokweng", "Mogoditshane", "Old Naledi",
            "Block 6", "Phase 2", "G-West", "Broadhurst", "Ledumang", "Bontleng",
            "Extension 13", "Riverwalk", "Kgale View", "Phakalane", "Mochudi Road")

        spinnerLoc.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, locations
        )

        val types = listOf("", "Single Room", "Double Room", "Bachelor Flat",
            "2-Bedroom Flat", "Cottage", "House")

        spinnerType.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, types
        )

        // Date picker — opens on field tap or calendar button tap
        val openDatePicker = {
            val cal = Calendar.getInstance()
            // If a date is already selected, open the picker at that date
            if (selectedDate.isNotEmpty()) {
                val parts = selectedDate.split("-")
                if (parts.size == 3) {
                    cal.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt())
                }
            }
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    selectedDate = "%04d-%02d-%02d".format(year, month + 1, day)
                    tvAvailDate.text = selectedDate
                    tvAvailDate.setTextColor(getColor(android.R.color.tab_indicator_text))
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        tvAvailDate.setOnClickListener { openDatePicker() }
        btnPickDate.setOnClickListener { openDatePicker() }

        // Load existing filter
        lifecycleScope.launch {
            val f = db.userFilterDao().getFilter(userId)
            runOnUiThread {
                f?.let {
                    val locIdx = locations.indexOf(it.location)
                    if (locIdx >= 0) spinnerLoc.setSelection(locIdx)

                    etMaxPrice.setText(if (it.maxPrice > 0) it.maxPrice.toString() else "")

                    if (it.availabilityDate.isNotEmpty()) {
                        selectedDate = it.availabilityDate
                        tvAvailDate.text = it.availabilityDate
                        tvAvailDate.setTextColor(getColor(android.R.color.tab_indicator_text))
                    }

                    val typeIdx = types.indexOf(it.type)
                    if (typeIdx >= 0) spinnerType.setSelection(typeIdx)
                }
            }
        }

        btnSave.setOnClickListener {
            val price = etMaxPrice.text.toString().toDoubleOrNull() ?: 0.0
            val filter = UserFilter(
                userId           = userId,
                maxPrice         = price,
                location         = spinnerLoc.selectedItem.toString(),
                type             = spinnerType.selectedItem.toString(),
                availabilityDate = selectedDate
            )
            lifecycleScope.launch {
                db.userFilterDao().saveFilter(filter)
                runOnUiThread {
                    Toast.makeText(
                        this@FilterActivity,
                        "Filters saved! You will be notified when listings match.",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                }
            }
        }

        btnClear.setOnClickListener {
            lifecycleScope.launch {
                val f = db.userFilterDao().getFilter(userId)
                if (f != null) db.userFilterDao().deleteFilter(f)
                runOnUiThread {
                    spinnerLoc.setSelection(0)
                    etMaxPrice.text.clear()
                    selectedDate = ""
                    tvAvailDate.text = "Tap to select a date"
                    spinnerType.setSelection(0)
                    Toast.makeText(this@FilterActivity, "Filters cleared", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnBack.setOnClickListener { finish() }
    }
}
