package com.example.almosthomeless.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.almosthomeless.R
import com.example.almosthomeless.models.Listing
import com.example.almosthomeless.models.Reservation

// -- Listing Adapter ----------------------------------------------------------
class ListingAdapter(
    private val listings: List<Listing>,
    private val onClick: (Listing) -> Unit
) : RecyclerView.Adapter<ListingAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val ivImage:    ImageView = view.findViewById(R.id.ivListingThumbnail)
        val tvTitle:    TextView = view.findViewById(R.id.tvListingTitle)
        val tvPrice:    TextView = view.findViewById(R.id.tvListingPrice)
        val tvLocation: TextView = view.findViewById(R.id.tvListingLocation)
        val tvStatus:   TextView = view.findViewById(R.id.tvListingStatus)
    }

    override fun getItemCount() = listings.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_listing, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val l = listings[position]
        
        // Load image using Coil
        if (l.imageUri != null) {
            holder.ivImage.load(l.imageUri) {
                placeholder(android.R.drawable.ic_menu_gallery)
                error(android.R.drawable.ic_menu_report_image)
            }
        } else {
            holder.ivImage.setImageResource(android.R.drawable.ic_menu_gallery)
        }

        holder.tvTitle.text    = l.title
        holder.tvPrice.text    = "BWP ${l.price}/mo"
        holder.tvLocation.text = l.location
        holder.tvStatus.text   = if (l.isReserved) "Reserved" else "Available"
        
        // Use theme colors
        holder.tvStatus.setTextColor(
            if (l.isReserved) 0xFFB71C1C.toInt() else 0xFF2E7D32.toInt()
        )
        holder.itemView.setOnClickListener { onClick(l) }
    }
}

// -- Reservation Adapter ------------------------------------------------------
class ReservationAdapter(
    private val items: List<Pair<Reservation, String>> // reservation + listing title
) : RecyclerView.Adapter<ReservationAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvReceipt:  TextView = view.findViewById(R.id.tvReceipt)
        val tvListing:  TextView = view.findViewById(R.id.tvResListing)
        val tvAmount:   TextView = view.findViewById(R.id.tvResAmount)
        val tvDate:     TextView = view.findViewById(R.id.tvResDate)
        val tvStatus:   TextView = view.findViewById(R.id.tvResStatus)
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_reservation, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val (res, title) = items[position]
        holder.tvReceipt.text = "Receipt: ${res.receiptNumber}"
        holder.tvListing.text = title
        holder.tvAmount.text  = "BWP ${res.paymentAmount} deposit paid"
        holder.tvDate.text    = "Date: ${res.reservationDate}"
        holder.tvStatus.text  = res.status
    }
}
