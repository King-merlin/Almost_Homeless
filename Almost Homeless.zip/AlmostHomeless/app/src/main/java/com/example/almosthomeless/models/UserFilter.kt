package com.example.almosthomeless.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_filters")
data class UserFilter(
    @PrimaryKey
    val userId: Int,
    val maxPrice: Double = 0.0,
    val location: String = "",
    val type: String = "",
    val availabilityDate: String = ""
)