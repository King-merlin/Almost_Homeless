package com.example.almosthomeless.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.almosthomeless.R
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.models.Message
import com.example.almosthomeless.utils.SessionManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var adapter: ChatAdapter
    private val messages = mutableListOf<Message>()
    private var myId: Int = -1
    private var otherId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        db      = AppDatabase.getDatabase(this)
        myId    = SessionManager.getUserId(this)
        otherId = intent.getIntExtra("OTHER_USER_ID", -1)

        val tvTitle   = findViewById<TextView>(R.id.tvChatTitle)
        val tvInitial = findViewById<TextView>(R.id.tvChatInitial)
        val rv        = findViewById<RecyclerView>(R.id.rvMessages)
        val etMsg     = findViewById<EditText>(R.id.etMessage)
        val btnSend   = findViewById<Button>(R.id.btnSend)
        val btnBack   = findViewById<ImageButton>(R.id.btnBack)

        btnBack.setOnClickListener { finish() }

        lifecycleScope.launch {
            val other = db.userDao().getUserById(otherId)
            runOnUiThread {
                tvTitle.text   = other?.fullname ?: "Chat"
                tvInitial.text = other?.fullname?.firstOrNull()?.uppercase() ?: "?"
            }
        }

        adapter = ChatAdapter(messages, myId)
        rv.layoutManager = LinearLayoutManager(this).also { it.stackFromEnd = true }
        rv.adapter = adapter

        btnSend.setOnClickListener {
            val text = etMsg.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            lifecycleScope.launch {
                db.messageDao().sendMessage(
                    Message(senderId = myId, receiverId = otherId, message = text)
                )
                runOnUiThread { etMsg.text.clear() }
                loadMessages(rv)
            }
        }

        lifecycleScope.launch {
            while (true) {
                loadMessages(rv)
                delay(3000)
            }
        }
    }

    private suspend fun loadMessages(rv: RecyclerView) {
        val chat = db.messageDao().getChat(myId, otherId)
        runOnUiThread {
            messages.clear()
            messages.addAll(chat)
            adapter.notifyDataSetChanged()
            if (messages.isNotEmpty()) rv.scrollToPosition(messages.size - 1)
        }
    }
}

class ChatAdapter(
    private val messages: List<Message>,
    private val myId: Int
) : RecyclerView.Adapter<ChatAdapter.MsgVH>() {

    inner class MsgVH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    override fun getItemCount() = messages.size

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): MsgVH {
        val tv = TextView(parent.context).apply {
            setPadding(36, 18, 36, 18)
            textSize = 15f
            maxWidth = (parent.width * 0.75).toInt()
        }
        return MsgVH(tv)
    }

    override fun onBindViewHolder(holder: MsgVH, position: Int) {
        val msg    = messages[position]
        val isMine = msg.senderId == myId
        holder.tv.text = msg.message

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = if (isMine) android.view.Gravity.END else android.view.Gravity.START
            setMargins(8, 4, 8, 4)
        }
        holder.tv.layoutParams = params
        holder.tv.setBackgroundResource(R.drawable.rounded_input)

        if (isMine) {
            holder.tv.backgroundTintList = ContextCompat.getColorStateList(holder.tv.context, R.color.purple_accent)
            holder.tv.setTextColor(ContextCompat.getColor(holder.tv.context, R.color.white))
        } else {
            holder.tv.backgroundTintList = ContextCompat.getColorStateList(holder.tv.context, R.color.surface_variant_light)
            holder.tv.setTextColor(ContextCompat.getColor(holder.tv.context, R.color.on_surface_light))
        }
    }
}
