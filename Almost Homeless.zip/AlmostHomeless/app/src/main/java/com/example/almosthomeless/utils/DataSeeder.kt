package com.example.almosthomeless.utils

import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.models.Listing
import com.example.almosthomeless.models.User

object DataSeeder {

    // h1-h26 only
    private val houseImages = (1..26).map { "h$it" }

    // Each landlord gets a fixed slice of images so their "portfolio" looks consistent
    private val landlordImageSlices = listOf(
        listOf("h1","h2","h3","h4","h5","h6","h7","h8","h9","h10"),
        listOf("h11","h12","h13","h14","h15","h16","h17","h18","h19","h20"),
        listOf("h21","h22","h23","h24","h25","h26","h1","h3","h5","h7"),
        listOf("h2","h4","h6","h8","h10","h12","h14","h16","h18","h20"),
        listOf("h9","h11","h13","h15","h17","h19","h21","h23","h25","h26")
    )

    suspend fun seed(db: AppDatabase) {
        if (db.userDao().getAllUsers().isNotEmpty()) return

        // ---- ADMIN ----
        db.userDao().register(
            User(fullname = "Admin", email = "admin@almosthomeless.bw",
                password = "admin123", role = "admin")
        )

        // ---- LANDLORDS (5, Tswana names) ----
        val landlordData = listOf(
            Triple("Keabetswe Molefe",  "keabetswe@landlord.bw",  "71230001"),
            Triple("Onthatile Sebego",  "onthatile@landlord.bw",  "71230002"),
            Triple("Kagiso Modise",     "kagiso@landlord.bw",     "71230003"),
            Triple("Boipelo Ramathe",   "boipelo@landlord.bw",    "71230004"),
            Triple("Tshepiso Kgosing",  "tshepiso@landlord.bw",   "71230005")
        )

        val landlordIds = landlordData.mapIndexed { idx, (name, email, phone) ->
            db.userDao().register(
                User(fullname = name, email = email, password = "pass123",
                    role = "landlord", phone = phone)
            ).toInt()
        }

        // ---- LISTINGS - 10 per landlord ----
        data class ListingTemplate(
            val title: String,
            val type: String,
            val location: String,
            val price: Double,
            val deposit: Double,
            val amenities: String,
            val availDate: String,
            val description: String
        )

        val allListings = listOf(
            // Landlord 0 - Keabetswe (Gaborone West & Phase 2)
            listOf(
                ListingTemplate("Cosy Single Room - Gaborone West","Single Room","Gaborone West",1800.0,1800.0,"WiFi, Water, Parking","2025-01-10","Quiet single room in a secure yard. Great for focused students."),
                ListingTemplate("Bachelor Flat - Phase 2","Bachelor Flat","Phase 2",2800.0,2800.0,"WiFi, Kitchen, Security","2025-02-01","Self-contained bachelor flat. All utilities included."),
                ListingTemplate("Double Room - Gaborone West","Double Room","Gaborone West",2200.0,2200.0,"WiFi, Shared Bathroom, Parking","2025-03-15","Spacious double room, shared with one other tenant."),
                ListingTemplate("2-Bedroom Flat - Phase 2","2-Bedroom Flat","Phase 2",4500.0,4500.0,"WiFi, DSTV, Parking, Security","2025-04-01","Modern flat, ideal for two students splitting rent."),
                ListingTemplate("Single Room - Gaborone West","Single Room","Gaborone West",1600.0,1600.0,"WiFi, Water","2025-05-01","Affordable single room in a family yard."),
                ListingTemplate("Cottage - Phase 2","Cottage","Phase 2",3500.0,3500.0,"WiFi, Kitchen, Parking, Garden","2025-06-01","Private cottage with a garden. Very peaceful."),
                ListingTemplate("Bachelor Flat - Gaborone West","Bachelor Flat","Gaborone West",2600.0,2600.0,"WiFi, Kitchen","2025-07-01","Neat bachelor. Walking distance to BUS route."),
                ListingTemplate("Double Room - Phase 2","Double Room","Phase 2",2400.0,2400.0,"WiFi, Shared Kitchen","2025-08-01","Double room in a shared house with other students."),
                ListingTemplate("House - Gaborone West","House","Gaborone West",6000.0,6000.0,"WiFi, Parking, Garden, DSTV, Security","2025-09-01","Full 3-bedroom house. Perfect for a group of friends."),
                ListingTemplate("Single Room - Phase 2","Single Room","Phase 2",1700.0,1700.0,"WiFi, Water, Security","2025-10-01","Recently painted single room with lockable door.")
            ),
            // Landlord 1 - Onthatile (Tlokweng & Block 6)
            listOf(
                ListingTemplate("Neat Bachelor - Tlokweng","Bachelor Flat","Tlokweng",2500.0,2500.0,"WiFi, Kitchen, Parking","2025-01-15","Well-maintained bachelor, 5 min from UB gate."),
                ListingTemplate("Single Room - Block 6","Single Room","Block 6",1900.0,1900.0,"WiFi, Water","2025-02-10","Single room in a quiet residential area."),
                ListingTemplate("Double Room - Tlokweng","Double Room","Tlokweng",2300.0,2300.0,"WiFi, Shared Bathroom","2025-03-01","Double room with large windows and good ventilation."),
                ListingTemplate("2-Bedroom Flat - Block 6","2-Bedroom Flat","Block 6",4800.0,4800.0,"WiFi, DSTV, Security, Parking","2025-04-15","Modern 2-bed flat, secure complex."),
                ListingTemplate("Bachelor Flat - Tlokweng","Bachelor Flat","Tlokweng",2700.0,2700.0,"WiFi, Kitchen","2025-05-15","Spacious bachelor with tiled floors throughout."),
                ListingTemplate("Single Room - Tlokweng","Single Room","Tlokweng",1750.0,1750.0,"WiFi, Water, Parking","2025-06-10","Affordable room in a well-kept yard."),
                ListingTemplate("House - Block 6","House","Block 6",5500.0,5500.0,"WiFi, Parking, Garden, Security","2025-07-01","3-bedroom house available for a group of students."),
                ListingTemplate("Cottage - Tlokweng","Cottage","Tlokweng",3200.0,3200.0,"WiFi, Kitchen, Parking","2025-08-15","Detached cottage with own entrance and parking."),
                ListingTemplate("Double Room - Block 6","Double Room","Block 6",2100.0,2100.0,"WiFi, Shared Kitchen","2025-09-01","Clean double room sharing kitchen with two others."),
                ListingTemplate("Single Room - Block 6","Single Room","Block 6",1650.0,1650.0,"WiFi, Water","2025-11-01","Budget-friendly room in a safe neighbourhood.")
            ),
            // Landlord 2 - Kagiso (Mogoditshane & Broadhurst)
            listOf(
                ListingTemplate("Furnished Bachelor - Mogoditshane","Bachelor Flat","Mogoditshane",3000.0,3000.0,"WiFi, Kitchen, Furnished, Parking","2025-02-01","Fully furnished bachelor. Move in and study."),
                ListingTemplate("Single Room - Broadhurst","Single Room","Broadhurst",1850.0,1850.0,"WiFi, Water, Security","2025-03-01","Single room in a gated yard with 24-hr security."),
                ListingTemplate("2-Bedroom Flat - Mogoditshane","2-Bedroom Flat","Mogoditshane",5000.0,5000.0,"WiFi, DSTV, Parking, Kitchen","2025-04-01","Spacious 2-bed flat, quiet street."),
                ListingTemplate("Double Room - Broadhurst","Double Room","Broadhurst",2350.0,2350.0,"WiFi, Shared Bathroom, Parking","2025-05-01","Double room in shared house, great community."),
                ListingTemplate("Cottage - Mogoditshane","Cottage","Mogoditshane",3400.0,3400.0,"WiFi, Kitchen, Garden","2025-06-01","Charming cottage with private garden space."),
                ListingTemplate("Single Room - Mogoditshane","Single Room","Mogoditshane",1700.0,1700.0,"WiFi, Water","2025-07-01","Compact but comfortable single room."),
                ListingTemplate("House - Broadhurst","House","Broadhurst",5800.0,5800.0,"WiFi, Parking, Garden, DSTV","2025-08-01","Spacious house ideal for 3-4 students sharing."),
                ListingTemplate("Bachelor Flat - Broadhurst","Bachelor Flat","Broadhurst",2900.0,2900.0,"WiFi, Kitchen, Parking","2025-09-01","Modern bachelor flat, recently renovated."),
                ListingTemplate("Double Room - Mogoditshane","Double Room","Mogoditshane",2200.0,2200.0,"WiFi, Shared Kitchen","2025-10-01","Double room in a student-friendly household."),
                ListingTemplate("Single Room - Broadhurst","Single Room","Broadhurst",1800.0,1800.0,"WiFi, Water, Parking","2025-11-15","Single room with private parking bay.")
            ),
            // Landlord 3 - Boipelo (Old Naledi & Bontleng)
            listOf(
                ListingTemplate("Single Room - Old Naledi","Single Room","Old Naledi",1500.0,1500.0,"Water, Parking","2025-01-20","Affordable room close to taxis and shops."),
                ListingTemplate("Double Room - Bontleng","Double Room","Bontleng",2000.0,2000.0,"WiFi, Shared Bathroom","2025-02-15","Double room, friendly landlord, safe area."),
                ListingTemplate("Bachelor Flat - Old Naledi","Bachelor Flat","Old Naledi",2400.0,2400.0,"WiFi, Kitchen","2025-03-10","Self-contained bachelor, walking distance to UB."),
                ListingTemplate("2-Bedroom Flat - Bontleng","2-Bedroom Flat","Bontleng",4200.0,4200.0,"WiFi, Parking, Security","2025-04-01","2-bed flat in a quiet part of Bontleng."),
                ListingTemplate("Cottage - Old Naledi","Cottage","Old Naledi",3100.0,3100.0,"WiFi, Kitchen, Parking","2025-05-01","Standalone cottage with separate entrance."),
                ListingTemplate("Single Room - Bontleng","Single Room","Bontleng",1600.0,1600.0,"Water, WiFi","2025-06-01","Clean single room, very affordable."),
                ListingTemplate("House - Old Naledi","House","Old Naledi",5000.0,5000.0,"WiFi, Parking, Garden","2025-07-01","Full house, great for a group of 4 students."),
                ListingTemplate("Double Room - Old Naledi","Double Room","Old Naledi",1950.0,1950.0,"WiFi, Shared Kitchen","2025-08-01","Double room in a friendly student household."),
                ListingTemplate("Bachelor Flat - Bontleng","Bachelor Flat","Bontleng",2600.0,2600.0,"WiFi, Kitchen, Security","2025-09-15","Neat and secure bachelor flat."),
                ListingTemplate("Single Room - Old Naledi","Single Room","Old Naledi",1450.0,1450.0,"Water, Parking","2025-12-01","Budget single room, great for first-year students.")
            ),
            // Landlord 4 - Tshepiso (Extension 13 & Phakalane)
            listOf(
                ListingTemplate("Modern Single - Extension 13","Single Room","Extension 13",2000.0,2000.0,"WiFi, Water, Security, Parking","2025-01-05","Newly built single room in a secure complex."),
                ListingTemplate("2-Bedroom Flat - Phakalane","2-Bedroom Flat","Phakalane",5500.0,5500.0,"WiFi, DSTV, Parking, Security, Pool","2025-02-01","Luxury 2-bed flat in a sought-after complex."),
                ListingTemplate("Bachelor - Extension 13","Bachelor Flat","Extension 13",3100.0,3100.0,"WiFi, Kitchen, Parking, Security","2025-03-01","Premium bachelor, modern finishes throughout."),
                ListingTemplate("Double Room - Phakalane","Double Room","Phakalane",2600.0,2600.0,"WiFi, Shared Bathroom, Parking","2025-04-01","Double room in a well-maintained property."),
                ListingTemplate("Cottage - Extension 13","Cottage","Extension 13",3800.0,3800.0,"WiFi, Kitchen, Garden, Parking","2025-05-01","Beautiful cottage with a private garden."),
                ListingTemplate("Single Room - Phakalane","Single Room","Phakalane",1950.0,1950.0,"WiFi, Water, Security","2025-06-15","Single room in a quiet Phakalane neighbourhood."),
                ListingTemplate("House - Extension 13","House","Extension 13",6500.0,6500.0,"WiFi, DSTV, Parking, Garden, Security","2025-07-01","Large modern house, fully walled and gated."),
                ListingTemplate("Bachelor Flat - Phakalane","Bachelor Flat","Phakalane",3200.0,3200.0,"WiFi, Kitchen, Security, Parking","2025-08-01","Upmarket bachelor in a secure estate."),
                ListingTemplate("Double Room - Extension 13","Double Room","Extension 13",2450.0,2450.0,"WiFi, Shared Kitchen, Security","2025-09-01","Double room sharing with one other professional tenant."),
                ListingTemplate("Single Room - Extension 13","Single Room","Extension 13",1900.0,1900.0,"WiFi, Water, Parking","2025-10-15","Clean single room, close to mall and transport.")
            )
        )

        landlordIds.forEachIndexed { lIdx, landlordId ->
            val images = landlordImageSlices[lIdx]
            allListings[lIdx].forEachIndexed { lNum, t ->
                val img = images[lNum % images.size]
                db.listingDao().insertListing(
                    Listing(
                        landlordId       = landlordId,
                        title            = t.title,
                        price            = t.price,
                        location         = t.location,
                        type             = t.type,
                        amenities        = t.amenities,
                        availabilityDate = t.availDate,
                        depositAmount    = t.deposit,
                        description      = t.description,
                        imageUri         = "android.resource://com.example.almosthomeless/drawable/$img"
                    )
                )
            }
        }

        // ---- STUDENTS - 50, Tswana names ----
        val studentFirstNames = listOf(
            "Aobakwe","Bontle","Chanda","Dineo","Emang","Fenyang","Gaone","Gofaone",
            "Gorata","Kagiso","Kealeboga","Kefilwe","Keitumetse","Keneilwe","Kgomotso",
            "Khumo","Kitso","Kobamelo","Kopano","Lebogang","Leeto","Lefika","Lerato",
            "Lesego","Loago","Lorato","Malebogo","Mapula","Masego","Mmaphuti","Mmasetlhoa",
            "Mmoloki","Moagi","Mompati","Morulaganyi","Motswedi","Mpho","Neo","Nkosi",
            "Ntshe","Obakeng","Olorato","Omphile","Onalenna","Onthatile","Oratile",
            "Phenyo","Pono","Refilwe","Rethabile"
        )
        val studentLastNames = listOf(
            "Molefe","Kgosi","Matshego","Sebego","Dintwe","Moeti","Phiri","Gabanakgosi",
            "Motswagole","Ramotshabi","Seretse","Moseki","Ntloedibe","Ntshole","Ramathe",
            "Modise","Gabankitse","Mosweunyane","Gaositwe","Kgosing","Sithole","Ndlovu",
            "Mooketsi","Tau","Keagile","Mogorosi","Lekgethwane","Basimanebotlhe"
        )

        studentFirstNames.forEachIndexed { i, first ->
            val last  = studentLastNames[i % studentLastNames.size]
            val email = "${first.lowercase()}.${last.lowercase()}@student.ub.bw"
            val sid   = "S20${20 + (i / 12)}${(1000 + i)}"
            db.userDao().register(
                User(
                    fullname  = "$first $last",
                    email     = email,
                    password  = "student123",
                    role      = "student",
                    studentId = sid,
                    phone     = "7${(6000000 + i * 7)}"
                )
            )
        }
    }
}
