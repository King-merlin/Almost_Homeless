package com.example.almosthomeless.activities

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.almosthomeless.R
import com.example.almosthomeless.adapters.ReservationAdapter
import com.example.almosthomeless.database.AppDatabase
import com.example.almosthomeless.utils.SessionManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val db     = AppDatabase.getDatabase(this)
        val userId = SessionManager.getUserId(this)

        val tvName      = findViewById<TextView>(R.id.tvProfileName)
        val tvEmail     = findViewById<TextView>(R.id.tvProfileEmail)
        val tvRole      = findViewById<TextView>(R.id.tvProfileRole)
        val tvInitial   = findViewById<TextView>(R.id.tvAvatarInitial)
        val tvNoBookings = findViewById<TextView>(R.id.tvNoBookings)
        val rvBookings  = findViewById<RecyclerView>(R.id.rvBookings)
        val btnLogout   = findViewById<Button>(R.id.btnLogout)
        val bottomNav   = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_profile
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, StudentDashboardActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatListActivity::class.java))
                    true
                }
                R.id.nav_profile -> true
                else -> false
            }
        }

        btnLogout.setOnClickListener {
            SessionManager.clearSession(this)
            startActivity(Intent(this, LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
        }

        rvBookings.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            val user = db.userDao().getUserById(userId)
            val reservations = db.reservationDao().getReservationsByStudent(userId)
            val enriched = reservations.map { res ->
                val listing = db.listingDao().getListingById(res.listingId)
                Pair(res, listing?.title ?: "Unknown listing")
            }

            runOnUiThread {
                user?.let {
                    tvName.text    = it.fullname
                    tvEmail.text   = it.email
                    tvRole.text    = it.role.replaceFirstChar { c -> c.uppercase() }
                    tvInitial.text = it.fullname.firstOrNull()?.uppercase() ?: "?"
                }

                if (enriched.isEmpty()) {
                    tvNoBookings.visibility = android.view.View.VISIBLE
                    rvBookings.visibility   = android.view.View.GONE
                } else {
                    tvNoBookings.visibility = android.view.View.GONE
                    rvBookings.visibility   = android.view.View.VISIBLE
                    rvBookings.adapter      = ReservationAdapter(enriched)
                }
            }
        }
    }
}
